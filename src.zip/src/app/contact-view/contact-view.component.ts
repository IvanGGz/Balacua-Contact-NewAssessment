import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ContactService } from 'src/app/contact.service';
import { ContactModel } from 'src/app/contact.model';


@Component({

  selector: 'app-contact-view',
  templateUrl: './contact-view.component.html',
  styleUrls: ['./contact-view.component.css']

})

export class ContactViewComponent implements OnInit {
 contact: ContactModel;

  constructor(
    private route: ActivatedRoute,
    private contactService: ContactService

  ) {}


  ngOnInit() {

    const id = +this.route.snapshot.paramMap.get('id');

    this.contactService.getContact(id).subscribe(contact => (this.contact = contact));

  }

}