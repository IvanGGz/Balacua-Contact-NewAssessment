import { Observable } from 'rxjs';


import { ContactModel } from 'src/app/contact.model';


import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


var http = {headers: new HttpHeaders({ 'Content-Type': 'application/json' })};

@Injectable()
export class ContactService {

Url: string = 'https://jsonplaceholder.typicode.com/users';
constructor(private _http: HttpClient) { }

GetUser(): Observable<ContactModel[]> {

     return this._http.get<ContactModel[]>(this.Url);

}

SaveUser(contactUser: ContactModel): Observable<ContactModel> {
     return this._http.post<ContactModel>(this.Url, contactUser, http);

 }

UpdateUserContact(contactUser: ContactModel): Observable<ContactModel> {
     const url = `${this.Url}/${contactUser.id}`;
     return this._http.put<ContactModel>(url, contactUser, http);

 }
getContact(id: number): Observable<ContactModel> { 
     const url = `${this.Url}/${id}`;
     return this._http.get<ContactModel>(url);

 }

removeContact(contact: ContactModel | number): Observable<ContactModel> {
     const id = typeof contact === 'number' ? contact : contact.id;
     const url = `${this.Url}/${id}`;
     return this._http.delete<ContactModel>(url, http);

 }

}