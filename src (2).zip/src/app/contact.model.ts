export interface ContactModel {

    id: number,
    name: string,
    email: string,
    phone: number
    
}

