import { Observable } from 'rxjs';


import { ContactModel } from 'src/app/contact.model';


import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


var http = {headers: new HttpHeaders({ 'Content-Type': 'application/json' })};

@Injectable()
export class ContactService {
constructor(private _http: HttpClient) { }

GetUser(): Observable<ContactModel[]> {

     return this._http.get<ContactModel[]>('https://jsonplaceholder.typicode.com/users');

}

SaveUser(contactUser: ContactModel): Observable<ContactModel> {
     return this._http.post<ContactModel>('https://jsonplaceholder.typicode.com/users', contactUser, http);

 }

UpdateUserContact(contactUser: ContactModel): Observable<ContactModel> {
     const url = `${'https://jsonplaceholder.typicode.com/users'}/${contactUser.id}`;
     return this._http.put<ContactModel>(url, contactUser, http);

 }
getContact(id: number): Observable<ContactModel> { 
     const url = `${'https://jsonplaceholder.typicode.com/users'}/${id}`;
     return this._http.get<ContactModel>(url);

 }

removeContact(contact: ContactModel | number): Observable<ContactModel> {
     const id = typeof contact === 'number' ? contact : contact.id;
     const url = `${'https://jsonplaceholder.typicode.com/users'}/${id}`;
     return this._http.delete<ContactModel>(url, http);

 }

}