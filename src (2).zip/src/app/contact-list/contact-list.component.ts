import { Component, OnInit } from '@angular/core';

import { ContactService } from 'src/app/contact.service';
import { ContactModel } from 'src/app/contact.model';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']

})

export class ContactListComponent implements OnInit {

  contacts: ContactModel[]; currentContact: ContactModel = {

              id: 0,
              name: '',
              email: '',
              phone: null

  };

  isEdit: boolean;

  constructor(private contactService: ContactService) { }

  ngOnInit() {
    this.contactService.GetUser().subscribe(contacts => {
      this.contacts = contacts;

    });

  }
  onNewContact(contact: ContactModel) {
    this.contacts.push(contact);

  }

  editContact(contact: ContactModel) {
    this.currentContact = contact;
    this.isEdit = true;

  }

  onUpdatedContact(contact: ContactModel) {
  this.contacts.forEach((cur, index) => {
      if (contact.id === cur.id) {
        this.contacts.splice(index, 1);
        this.contacts.push(contact);
        this.isEdit = false;
        this.currentContact = {

            id: 0,
            name: '',
            email: '',
            phone: null

        };

      }

    });

  }


  removeContact(contact: ContactModel) {

    if (confirm('Are You Sure?')) {
      this.contactService.removeContact(contact.id).subscribe(() => {
        this.contacts.forEach((cur, index) => {
          if (contact.id === cur.id) {
            this.contacts.splice(index, 1);

          }

        });

      });

    }

  }

}