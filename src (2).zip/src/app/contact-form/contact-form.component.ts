import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { ContactService } from 'src/app/contact.service';



import { ContactModel } from 'src/app/contact.model';




@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']

})

export class ContactFormComponent implements OnInit {
  @Input() ngContact: ContactModel;
  @Input() isEdit: boolean;
  @Output() newContact: EventEmitter<ContactModel> = new EventEmitter();
  @Output() updatedContact: EventEmitter<ContactModel> = new EventEmitter();
  model: any;

  constructor(private ContactService: ContactService) {
    
   }
  ngOnInit() {
  }


  addUserContact({name, email, phone}) {


    if (!name || !email || !phone) {
    console.log('Field should not be empty');
       } 
    else {

      this.ContactService.SaveUser({ name, email, phone } as ContactModel).subscribe(contact => {
          this.newContact.emit(contact);
      
      });     
    }

  }

  UpdateUserContact() {
       this.ContactService.UpdateUserContact(this.ngContact).subscribe(contact => {

      console.log(contact);
      this.isEdit = false;
      this.updatedContact.emit(contact);

    });

  }
  


}