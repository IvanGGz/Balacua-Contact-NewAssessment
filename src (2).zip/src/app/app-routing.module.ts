import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactListComponent } from './contact-list/contact-list.component';
import { ContactViewComponent } from './contact-view/contact-view.component';
import { NotFoundComponent } from './not-found/not-found.component';




const routes: Routes = [

    { path: '', component: ContactListComponent },
    { path: 'contact/:id', component: ContactViewComponent },
    { path: '**', component: NotFoundComponent }

];

@NgModule({

    exports: [RouterModule],

    imports: [
        RouterModule.forRoot(routes)
    ]

})

export class AppRoutingModule { }